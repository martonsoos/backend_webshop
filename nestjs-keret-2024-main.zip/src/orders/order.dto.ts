import { IsString, IsNotEmpty, IsOptional, IsEmail, Length } from 'class-validator';

export class OrderDto {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  billingAddress: string; // Itt részletezhetnéd az országot, irányítószámot, stb.

  @IsString()
  @IsNotEmpty()
  shippingAddress: string; // Ugyanaz, mint a billingAddress

  @IsString()
  @IsOptional()
  @Length(5, 5, { message: 'Kuponkód formátuma: BB-SSSS' })
  couponCode?: string;

  @IsString()
  @IsNotEmpty()
  paymentMethod: string; // Bankkártya vagy egyéb

  // További bankkártya adatok...
}
