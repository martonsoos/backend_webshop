import { Injectable } from '@nestjs/common';
import { OrderDto } from './order.dto';

@Injectable()
export class OrderService {
  async createOrder(orderDto: OrderDto) {
    // Rendelés mentése az adatbázisba vagy egyéb logika
    console.log(orderDto);
  }
}
