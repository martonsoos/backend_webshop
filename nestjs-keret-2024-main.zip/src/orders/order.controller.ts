import { Controller, Post, Body, Render } from '@nestjs/common';
import { OrderService } from './order.service';
import { OrderDto } from './order.dto';

@Controller('order')
export class OrderController {
  constructor(private readonly orderService: OrderService) {}

  @Post()
  @Render('success.hbs') // Az átirányítás sikeres rendelés után
  async createOrder(@Body() orderDto: OrderDto) {
    // Itt kezeljük a rendelést
    await this.orderService.createOrder(orderDto);
    return { message: 'Sikeres rendelés!' };
  }
}
