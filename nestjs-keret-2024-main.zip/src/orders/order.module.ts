import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OrderController } from './order.controller';
import { OrderService } from './order.service';
import { App } from '../apps/app.entity'; // Az alkalmazás entitás importálása

@Module({
  imports: [TypeOrmModule.forFeature([App])],
  controllers: [OrderController],
  providers: [OrderService],
})
export class OrderModule {}
